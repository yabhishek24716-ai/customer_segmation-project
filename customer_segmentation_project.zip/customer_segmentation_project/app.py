from pathlib import Path
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

ROOT = Path(__file__).resolve().parent
DATA_PATH = ROOT / "data" / "customers.csv"

st.set_page_config(page_title="Customer Segmentation", page_icon="🛍️", layout="wide")
st.title("🛍️ Customer Segmentation Dashboard")
st.caption("Explore customer groups using demographics and shopping behavior. Demo data is synthetic.")

df = pd.read_csv(DATA_PATH)
features = ["Age", "AnnualIncome", "SpendingScore", "AnnualPurchases",
            "WebsiteVisitsPerMonth", "LoyaltyYears"]

with st.sidebar:
    st.header("Model settings")
    k = st.slider("Number of customer segments (K)", min_value=2, max_value=8, value=4)
    st.write("Clustering features")
    st.write(", ".join(features))

X = df[features].fillna(df[features].median(numeric_only=True))
scaled = StandardScaler().fit_transform(X)
model = KMeans(n_clusters=k, random_state=42, n_init=10)
df["Segment"] = model.fit_predict(scaled) + 1

c1, c2, c3 = st.columns(3)
c1.metric("Customers", f"{len(df):,}")
c2.metric("Segments", k)
c3.metric("Average annual income", f"₹{df['AnnualIncome'].mean():,.0f}")

left, right = st.columns(2)
with left:
    st.subheader("Income vs spending")
    fig, ax = plt.subplots(figsize=(7, 4))
    sns.scatterplot(data=df, x="AnnualIncome", y="SpendingScore", hue="Segment",
                    palette="tab10", s=55, ax=ax)
    ax.set_title("Customer groups")
    st.pyplot(fig)
    plt.close(fig)

with right:
    st.subheader("Customers per segment")
    counts = df["Segment"].value_counts().sort_index()
    fig, ax = plt.subplots(figsize=(7, 4))
    counts.plot(kind="bar", ax=ax)
    ax.set_xlabel("Segment")
    ax.set_ylabel("Number of customers")
    st.pyplot(fig)
    plt.close(fig)

st.subheader("Segment profile")
summary = df.groupby("Segment").agg(
    CustomerCount=("CustomerID", "count"),
    AverageAge=("Age", "mean"),
    AverageAnnualIncome=("AnnualIncome", "mean"),
    AverageSpendingScore=("SpendingScore", "mean"),
    AverageAnnualPurchases=("AnnualPurchases", "mean"),
    AverageWebsiteVisits=("WebsiteVisitsPerMonth", "mean"),
    AverageLoyaltyYears=("LoyaltyYears", "mean")
).round(1)
st.dataframe(summary, use_container_width=True)

st.subheader("Customer records")
segment_filter = st.multiselect("Filter by segment", sorted(df["Segment"].unique()),
                                default=sorted(df["Segment"].unique()))
filtered = df[df["Segment"].isin(segment_filter)]
st.dataframe(filtered, use_container_width=True)
st.download_button("Download segmented CSV",
                   data=filtered.to_csv(index=False).encode("utf-8"),
                   file_name="segmented_customers.csv",
                   mime="text/csv")

st.subheader("Example business actions")
st.markdown("""
- **High income + high spending:** offer premium products and early access.
- **High income + low spending:** test personalized offers and product recommendations.
- **Lower income + high spending:** use loyalty rewards and value bundles.
- **Low activity / low spending:** try re-engagement campaigns and helpful reminders.

These are example interpretations. Review each segment's actual profile before making business decisions.
""")
