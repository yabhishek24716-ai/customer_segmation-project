from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "customers.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

def main():
    df = pd.read_csv(DATA_PATH)
    print("Dataset shape:", df.shape)
    print("\nMissing values:\n", df.isna().sum())
    print("\nPreview:\n", df.head())

    features = [
        "Age", "AnnualIncome", "SpendingScore",
        "AnnualPurchases", "WebsiteVisitsPerMonth", "LoyaltyYears"
    ]
    X = df[features].copy()
    X = X.fillna(X.median(numeric_only=True))
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # Elbow curve to help select K
    inertias = []
    candidates = range(2, 9)
    for k in candidates:
        model = KMeans(n_clusters=k, random_state=42, n_init=10)
        model.fit(X_scaled)
        inertias.append(model.inertia_)

    plt.figure(figsize=(7, 4))
    plt.plot(list(candidates), inertias, marker="o")
    plt.title("Elbow Method for K-Means")
    plt.xlabel("Number of clusters (K)")
    plt.ylabel("Inertia")
    plt.tight_layout()
    plt.savefig(OUT / "elbow_method.png", dpi=160)
    plt.close()

    # K=4 is a useful starting point for this demo; inspect elbow curve before production use.
    model = KMeans(n_clusters=4, random_state=42, n_init=10)
    df["Segment"] = model.fit_predict(X_scaled) + 1

    # Segment profiles
    summary = df.groupby("Segment").agg(
        CustomerCount=("CustomerID", "count"),
        AverageAge=("Age", "mean"),
        AverageAnnualIncome=("AnnualIncome", "mean"),
        AverageSpendingScore=("SpendingScore", "mean"),
        AverageAnnualPurchases=("AnnualPurchases", "mean"),
        AverageWebsiteVisits=("WebsiteVisitsPerMonth", "mean"),
        AverageLoyaltyYears=("LoyaltyYears", "mean")
    ).round(2)
    summary.to_csv(OUT / "segment_summary.csv")
    df.to_csv(OUT / "segmented_customers.csv", index=False)

    # Segment scatter plot
    plt.figure(figsize=(8, 5))
    sns.scatterplot(
        data=df, x="AnnualIncome", y="SpendingScore",
        hue="Segment", palette="tab10", s=65
    )
    plt.title("Customer Segments: Income vs Spending Score")
    plt.xlabel("Annual income")
    plt.ylabel("Spending score (1-100)")
    plt.tight_layout()
    plt.savefig(OUT / "customer_segments.png", dpi=160)
    plt.close()

    print("\nSegment summary:\n", summary)
    print(f"\nSaved outputs to: {OUT}")

if __name__ == "__main__":
    main()
