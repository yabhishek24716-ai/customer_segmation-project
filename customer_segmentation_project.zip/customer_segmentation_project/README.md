# Customer Segmentation Project

A beginner-friendly Data Analytics / Machine Learning project that groups customers by demographics and shopping behavior using K-Means clustering.

## Project goals
- Explore customer demographics and purchase behavior.
- Standardize numeric features and use the Elbow Method to choose a cluster count.
- Segment customers with K-Means.
- Visualize customer groups and export the segmented dataset.
- Provide business recommendations for each segment.

## Dataset
`data/customers.csv` is a reproducible sample dataset of 500 fictional customers. It includes age, annual income, spending score, annual purchases, website visits, loyalty tenure, gender, and region. It is synthetic, not real customer data.

## Setup
Python 3.10+ recommended.

```bash
pip install -r requirements.txt
```

## Run the analysis
From this folder:

```bash
python src/customer_segmentation.py
```

The script saves:
- `outputs/segmented_customers.csv`
- `outputs/elbow_method.png`
- `outputs/customer_segments.png`
- `outputs/segment_summary.csv`

## Optional interactive dashboard
```bash
streamlit run app.py
```

## Main workflow
1. Load and inspect data.
2. Check missing values and duplicates.
3. Scale numeric features.
4. Use the Elbow Method to examine candidate values of K.
5. Fit K-Means and assign a segment to each customer.
6. Compare segment profiles and visualize results.
7. Translate findings into marketing actions.

## Important note
This is a learning/demo project. The generated sample data does not represent actual customers, and cluster labels are patterns rather than ground-truth categories.
